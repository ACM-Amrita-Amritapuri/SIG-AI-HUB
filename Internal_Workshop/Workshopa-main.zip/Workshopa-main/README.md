This Repository Consists of the Presaentations and the Demonstrations of the following Concepts of AI:
1)Generative Ai
2)Large Language Model's
3)Retrieval Augumented Genaeration
4)Transfer Learning
5)Computer Vision
6)Natural language processing
7)Recurrent Neural Networks,Long Short Term Memory,Gated recurrent Unit
8)Hyperparameter Tuning
